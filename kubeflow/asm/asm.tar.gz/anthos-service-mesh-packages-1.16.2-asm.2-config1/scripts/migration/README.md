# Istio Addon for GKE 1.4 to 1.6 migration script

This script can be used to automate some parts of the 1.4 to 1.6 upgrade. 
See the official [addon upgrade documentation](https://cloud.google.com/istio/docs/istio-on-gke/upgrade-with-operator)
for more details.
